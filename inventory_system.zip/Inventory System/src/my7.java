import java.awt.*;
import java.awt.event.*;
import java.sql.*;
class my7 extends Frame implements ActionListener
{
Label  l2,l3,l4,l5,l6,l8,l9,l10,l11,l12,l13;
TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
Button b3,b4;
Connection con;Statement st;ResultSet rs;
Font f1,f2;

my7()
{
setLayout(null);

 
l3=new Label("Item Code:");
t1=new TextField(10);

b3=new Button("Delete");
b3.setBounds(150,210,70,50);
b3.addActionListener(this);
add(b3);
b4=new Button("CANCEL");
b4.setBounds(250,210,70,50);
b4.addActionListener(this);
add(b4);


l3.setBounds(100,150,110,25);       
add(l3);
t1.setBounds(250,150,100,35); 
add(t1);



Font f3 = new Font("Item Code:",Font.BOLD,20);
l3.setFont(f3);

addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});

try
{
Class.forName("com.mysql.jdbc.Driver");    
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/inv","root","root");
st=con.createStatement();

rs=st.executeQuery("select * from aditem");
}catch(Exception e)
{
System.out.println("EXC  "+e);
}
}

public void actionPerformed(ActionEvent a)
{

String s1=t1.getText();
try
{


st.executeUpdate("DELETE FROM aditem WHERE item_code='"+s1+"'  ");
if(a.getSource()==b4)
{
dispose();
}
rs.close();
st.close();
con.close();

}catch(Exception e){System.out.println("Exc "+e);}



}

}