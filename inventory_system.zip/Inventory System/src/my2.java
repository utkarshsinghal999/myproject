import java.awt.*;
import java.sql.*;
import java.awt.event.*;
class my2 extends Frame implements ActionListener 
{
Label l1,l2,l3; Button b1,b2; TextField t1,t2; Font f1,f2,f3,f4,f5;
Connection con;Statement st;ResultSet rs;
my2()
{
//setLayout(null);
setSize(1400,730);
setLocation(0,0);
BackgroundPanel32 bp = new BackgroundPanel32();

l1=new Label("LOGIN PAGE");
f1=new Font("LOGIN PAGE",Font.BOLD,85);
l1.setFont(f1);
l1.setForeground(Color.white);
l2=new Label("USERNAME-");
f2=new Font("USERNAME",Font.BOLD,30);
l2.setFont(f2);
l2.setForeground(Color.white);
l3=new Label("PASSWORD-");
f3=new Font("PASSWORD",Font.BOLD,30);
l3.setFont(f3);
l3.setForeground(Color.white);
b1=new Button("LOGIN");
f4=new Font("LOGIN",Font.BOLD,30);
b1.setFont(f4);
b1.setForeground(Color.white);
b1.setBackground(Color.black);
b2=new Button("CANCEL");
f5=new Font("CANCEL",Font.BOLD,30);
b2.setFont(f5);
b2.setForeground(Color.white);
b2.setBackground(Color.black);
t1=new TextField(20);
t1.setFont(new Font("Console",Font.BOLD,20));  // set font of textfield
t1.setBackground(Color.pink);
t1.setForeground(Color.black);
t2=new TextField(20);
t2.setFont(new Font("Console",Font.BOLD,20)); 
t2.setBackground(Color.pink);
t2.setForeground(Color.black);
l1.setBounds(410,100,550,110);
add(l1);
l2.setBounds(450,300,190,40);
add(l2);
l3.setBounds(450,350,190,40);
add(l3);
t1.setBounds(650,300,200,40);
add(t1);
t2.setBounds(650,350,200,40);
add(t2);
b1.setBounds(650,420,120,70);
b1.addActionListener(this);
add(b1);
b2.setBounds(790,420,140,70);
b2.addActionListener(this);
add(b2);

add(bp);


addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});


try
{
Class.forName("com.mysql.jdbc.Driver");    
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/inv","root","root");
st=con.createStatement();//3
rs=st.executeQuery("select * from login");
}catch(Exception e)
{
System.out.println("EXC  "+e);
}

}
public void actionPerformed(ActionEvent a)
{
String s1=t1.getText();
String s2=t2.getText();
try
{
if(a.getSource()==b1)
{

int f=0;
while(rs.next())
{
String s3=rs.getString("username");
String s4=rs.getString("password");
String s5=rs.getString("role");

if(s1.equals(s3) && s2.equals(s4))
 {
if(s5.equals("admin"))
{
      ad1 a1=new ad1();
      a1.setSize(1500,1500);
      a1.setBackground(Color.red);
      a1.setVisible(true);
}
else
    {
       md1 d1=new md1();
       d1.setSize(1500,1500);
       d1.setBackground(Color.blue);
       d1.setVisible(true);
     }
}
}
}
if(a.getSource()==b2)
{
dispose();
}
rs.close();
st.close();
con.close();
}catch(Exception e)
{
System.out.println("EXC  "+e);
}
}
}




class BackgroundPanel32 extends Panel
{
Image img;
 BackgroundPanel32()
{
try
{
img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("login.jpg"), "login.jpg"));
}
catch(Exception e){/*handled in paint()*/}
}
public void paint(Graphics g)
{
super.paint(g);
if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
else g.drawString("No Image",100,100);
}
}

