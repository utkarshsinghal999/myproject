
import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
class userlist extends JFrame {
    DefaultTableModel model = new DefaultTableModel();
    Container cnt = this.getContentPane();
    JTable jtbl = new JTable(model);
    public userlist() {
       
        model.addColumn("Item Name");
        model.addColumn("Item Code");
        model.addColumn("Mfg.");
        model.addColumn("Exp.");
        model.addColumn("Company");
        model.addColumn("Location");
        model.addColumn("Batch");
        model.addColumn("Purchase_Price");
        model.addColumn("Closing_Stock");
        model.addColumn("Re_Order_Value");
      
   
    jtbl.setBounds(1400,730,1400,730);
    jtbl.getTableHeader().setBackground(Color.PINK);
    jtbl.getTableHeader().setFont(new Font("Arial",Font.BOLD,20));
    jtbl.getTableHeader().setPreferredSize(new Dimension(20,50));
    jtbl.setFont(new Font("Arial",Font.PLAIN,15));
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/inv", "root", "root");
            PreparedStatement pstm = con.prepareStatement("SELECT * FROM aditem");
            ResultSet Rs = pstm.executeQuery();
            while(Rs.next()){
                model.addRow(new Object[]{Rs.getString(1), Rs.getInt(2),Rs.getDate(3),Rs.getDate(4),Rs.getString(5),Rs.getString(6),Rs.getString(7),Rs.getInt(8),Rs.getInt(9),Rs.getInt(10)});
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        JScrollPane pg = new JScrollPane(jtbl);
        cnt.add(pg);
        this.pack();
        pg.getViewport().setBackground(Color.GRAY);
    }
}