import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class menu1 extends JFrame
{
JLabel jlab;
menu1()
{
JFrame jfrm= new JFrame("Menu Demo");
jfrm.setLayout(new FlowLayout());
jfrm.setSize(1400,1400);
jfrm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
jlab= new JLabel();

JMenuBar jmb= new JMenuBar();

//Create item menu bar
JMenu jitem= new JMenu("ITEM");
JMenuItem jnew1= new JMenuItem("New");
JMenuItem jedit1= new JMenuItem("Edit");
JMenuItem jdelt1= new JMenuItem("Delete");
JMenuItem jview1=new JMenuItem("View");

jitem.add(jnew1);
jitem.add(jview1);
jitem.add(jedit1);
jitem.add(jdelt1);


//Create billing menu bar

JMenu jbill= new JMenu("BILLING");
JMenuItem jnew2= new JMenuItem("New");
JMenuItem jedit2= new JMenuItem("Edit");
JMenuItem jdelt2= new JMenuItem("Delete");
JMenuItem jview2=new JMenuItem("View");

jbill.add(jnew2);
jbill.add(jview2);
jbill.add(jedit2);
jbill.add(jdelt2);

// create customer menu bar
JMenu jcust=new JMenu("CUSTOMER");
JMenuItem jnew3=new JMenuItem("New");
JMenuItem jview3=new JMenuItem("View");
JMenuItem jedit3=new JMenuItem("Edit");
JMenuItem jdelt3=new JMenuItem("Delete");

jcust.add(jnew3);
jcust.add(jview3);
jcust.add(jedit3);
jcust.add(jdelt3);

//create vendor menu bar
JMenu jvendor=new JMenu("VENDOR");
JMenuItem jnew4=new JMenuItem("New");
JMenuItem jview4=new JMenuItem("View");
JMenuItem jedit4=new JMenuItem("Edit");
JMenuItem jdelt4=new JMenuItem("Delete");

jvendor.add(jnew4);
jvendor.add(jview4);
jvendor.add(jedit4);
jvendor.add(jdelt4);


jfrm.add(jlab);
jfrm.setJMenuBar(jmb);
jfrm.add(jitem);
jfrm.add(jbill);
jfrm.add(jcust);
jfrm.add(jvendor);
jfrm.setVisible(true);




}



public static void main(String args[])
{
SwingUtilities.invokeLater(new Runnable() 
{
public void run()
{
new menu1();
}
});
}
}


