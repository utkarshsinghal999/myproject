
import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
class userlist1 extends JFrame {
    DefaultTableModel model = new DefaultTableModel();
    Container cnt = this.getContentPane();
    JTable jtbl = new JTable(model);
    public userlist1() {
         model.addColumn("Amount");
        model.addColumn("Customer Name");
        model.addColumn("Item Name");
        model.addColumn("Batch");
        model.addColumn("Company");
        model.addColumn("Bill No.");
        model.addColumn("Delivery Address");
        model.addColumn("Contact Number");
        model.addColumn("Date");
        model.addColumn("Item Code");
        model.addColumn("Exp.");
        model.addColumn("Payment Mode");
        
       
       
    jtbl.setBounds(1400,730,1400,730);
    jtbl.getTableHeader().setBackground(Color.PINK);
    jtbl.getTableHeader().setFont(new Font("Arial",Font.BOLD,20));
    jtbl.getTableHeader().setPreferredSize(new Dimension(20,50));
    jtbl.setFont(new Font("Arial",Font.PLAIN,15));
    
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/inv", "root", "root");
            PreparedStatement pstm = con.prepareStatement("SELECT * FROM newbill");
            ResultSet Rs = pstm.executeQuery();
            while(Rs.next()){
                model.addRow(new Object[]{Rs.getInt(1), Rs.getString(2),Rs.getString(3),Rs.getString(4),Rs.getString(5),Rs.getInt(6),Rs.getString(7),Rs.getDouble(8),Rs.getString(9),Rs.getInt(10),Rs.getString(11),Rs.getString(12)});
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        JScrollPane pg = new JScrollPane(jtbl);
        cnt.add(pg);
        this.pack();
         pg.getViewport().setBackground(Color.GRAY);
    }
}
