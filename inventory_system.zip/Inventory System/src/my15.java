import java.awt.*;
import java.awt.event.*;
import java.sql.*;
class my15 extends Frame 
{
Label  l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13;
TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12;
Button b1,b2,b3;
Checkbox c1,c2,c3,c4;
Font f1,f2;
Connection con;Statement st;ResultSet rs;

my15()
{
setLayout(null);

l1=new Label("Item code:");




t1=new TextField(10);


b3=new Button("Edit");
b3.setBounds(150,210,70,50);

add(b3);
b2=new Button("Cancel");
b2.setBounds(250,210,70,50);
add(b2);


l1.setBounds(100,150,110,25);        
add(l1);

t1.setBounds(250,150,100,35); 
add(t1);


Font f6 = new Font("Item code :",Font.BOLD,20);
l1.setFont(f6);

addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
}
}