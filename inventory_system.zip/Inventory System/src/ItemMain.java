import java.awt.*;

class Item extends Frame
{
 Label l1;
 TextField t1;
 Item()
 {
  setLayout(null);
  l1=new Label("Item Name/Code");
  t1=new TextField(20);
  l1.setBounds(100,100,100,100);
  t1.setBounds(50,50,50,50);
  
  add(l1);
  add(t1);
 }
}
class ItemMain
{
 public static void main(String arg[])
 {
  Item I=new Item();
  I.setSize(500,400);
  Color c=new Color(100,50,50);
  I.setVisible(true);
  I.setBackground(c);
 }
}