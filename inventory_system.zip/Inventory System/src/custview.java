
import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
class UserList extends JFrame {
    DefaultTableModel model = new DefaultTableModel();
    Container cnt = this.getContentPane();
    JTable jtbl = new JTable(model);
    public UserList() {
        cnt.setLayout(new FlowLayout(FlowLayout.LEFT));
        model.addColumn("Customer Name");
        model.addColumn("Phone");
        model.addColumn("Mobile");
        model.addColumn("E-mail");
        model.addColumn("Fax");
        model.addColumn("Delivery Address");
        model.addColumn("Bank Account Number");
        model.addColumn("IFSC Code");
        model.addColumn("Reference");
    
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/inv", "root", "root");
            PreparedStatement pstm = con.prepareStatement("SELECT * FROM customer");
            ResultSet Rs = pstm.executeQuery();
            while(Rs.next()){
                model.addRow(new Object[]{Rs.getString(1), Rs.getInt(2),Rs.getInt(3),Rs.getString(4),Rs.getString(5),Rs.getString(6),Rs.getInt(7),Rs.getString(8),Rs.getString(9)});
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        JScrollPane pg = new JScrollPane(jtbl);
        cnt.add(pg);
        this.pack();
    }
}

public class custview{
    public static void main(String[] args) {
        JFrame frame = new UserList();
        frame.setTitle("Customer View");
        frame.setSize(900, 900);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
    }
}