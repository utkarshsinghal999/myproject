import java.awt.*;
import java.awt.event.*;
import java.sql.*;
class my9 extends Frame implements ActionListener
{
Label  l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10 ;
Button b1,b2,b3;
Connection con;Statement st;ResultSet rs;
Font f1,f2;

my9()
{

setLayout(null);

 
l3=new Label("Customer Name:");
t1=new TextField(10);

b3=new Button("Delete");
b3.setBounds(150,210,70,50);
b3.addActionListener(this);
add(b3);
b2=new Button("CANCEL");
b2.setBounds(250,210,70,50);
b2.addActionListener(this);
add(b2);


l3.setBounds(100,150,150,25);       
add(l3);
t1.setBounds(250,150,100,35); 
add(t1);



Font f3 = new Font("Customer Name:",Font.BOLD,15);
l3.setFont(f3);

addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});

try
{
Class.forName("com.mysql.jdbc.Driver");    
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/inv","root","root");
st=con.createStatement();

rs=st.executeQuery("select * from newcust");
}catch(Exception e)
{
System.out.println("EXC  "+e);
}
}

public void actionPerformed(ActionEvent a)
{

String s1=t1.getText();
try
{


st.executeUpdate("DELETE FROM newcust WHERE Customer_name='"+s1+"'  ");
if(a.getSource()==b2)
{
dispose();
}
rs.close();
st.close();
con.close();

}catch(Exception e){System.out.println("Exc "+e);}



}

}