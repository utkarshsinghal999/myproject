import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
class my4 extends Frame implements ActionListener
{
Label  l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13;
TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12;
Button b1,b2,b3;
Connection con;Statement st;ResultSet rs;
Checkbox c1,c2,c3,c4;
Font f1,f2;
public void paint(Graphics g)
{
g.drawRect(60,170,1270,450);
}
my4()
{
//setLayout(null);
setSize(1400,730);
setLocation(0,0);
BackgroundPanel89 bp = new BackgroundPanel89();

 
l1=new Label("Amount         :");
l2=new Label("Customer Name :");
l3=new Label("Item Name          :");
l4=new Label("Batch                :");
l5=new Label("Company           :");
l6=new Label("Bill no.              :");
l7=new Label("Delivery Add.  :");
l8=new Label("Contact no.     :");
l9=new Label("Date              :");
l10=new Label("Item Code       :");
l11=new Label("Exp. Date        :");
l12=new Label("Payment Method :");



l13=new Label("BILL");
 

CheckboxGroup cbg=new CheckboxGroup();
c1=new Checkbox("cash",cbg,true);
c2=new Checkbox("cheque",cbg,false);
c3=new Checkbox("credit",cbg,false);
c4=new Checkbox("other",cbg,false);




t1=new TextField(10);
t2=new TextField(20);
t3=new TextField(30);
t4=new TextField(40);
t5=new TextField(50);
t6=new TextField(60);
t7=new TextField(70);
t8=new TextField(80);
t9=new TextField(90); 
t11=new TextField(110);
t12=new TextField(30);

 
b3=new Button("Save");
b3.setBounds(550,640,100,70);
b3.addActionListener(this);
add(b3);
b2=new Button("Cancel");
b2.setBounds(700,640,100,70);
b2.addActionListener(this);
add(b2);


l1.setBounds(700,200,180,25); 
l1.setForeground(Color.pink);
l1.setBackground(Color.black);       
add(l1);
l2.setBounds(110,200,170,25); 
l2.setForeground(Color.pink);
l2.setBackground(Color.black);      
add(l2);
l3.setBounds(110,270,170,25);  
l3.setForeground(Color.pink);
l3.setBackground(Color.black);     
add(l3);
l4.setBounds(110,340,170,25); 
l4.setForeground(Color.pink);
l4.setBackground(Color.black);      
add(l4);
l5.setBounds(110,410,170,25); 
l5.setForeground(Color.pink);
l5.setBackground(Color.black);      
add(l5);
l6.setBounds(110,480,170,25);
l6.setForeground(Color.pink);
l6.setBackground(Color.black);     
add(l6);
l7.setBounds(110,550,170,25);  
l7.setForeground(Color.pink);
l7.setBackground(Color.black);    
add(l7);
l8.setBounds(700,270,170,25); 
l8.setForeground(Color.pink);
l8.setBackground(Color.black);    
add(l8);
l9.setBounds(700,340,170,25); 
l9.setForeground(Color.pink);
l9.setBackground(Color.black);   
add(l9);
l10.setBounds(700,410,170,25);
l10.setForeground(Color.pink);
l10.setBackground(Color.black);   
add(l10);
l11.setBounds(700,480,170,25); 
l11.setForeground(Color.pink);
l11.setBackground(Color.black);   
add(l11);
l12.setBounds(700,550,190,25);  
l12.setForeground(Color.pink);
l12.setBackground(Color.black); 
add(l12);
l13.setBounds(520,50,700,100);   
add(l13);


c1.setBounds(1000,550,90,30);
add(c1);
c2.setBounds(1000,580,90,30);
add(c2);
c3.setBounds(1100,550,90,30);
add(c3);
c4.setBounds(1100,580,90,30);
add(c4);
 



t1.setBounds(400,270,220,35); 
add(t1);
t2.setBounds(400,340,220,35); 
add(t2);
t3.setBounds(400,410,220,35); 
add(t3);
t4.setBounds(400,480,220,35); 
add(t4);
t5.setBounds(400,550,220,35); 
add(t5);
t6.setBounds(1000,270,220,35); 
add(t6);
t7.setBounds(1000,340,220,35); 
add(t7);
t8.setBounds(1000,410,220,35); 
add(t8);
t9.setBounds(1000,480,220,35); 
add(t9);
 
t11.setBounds(400,200,220,35); 
add(t11);
t12.setBounds(1000,200,220,35); 
add(t12);


Font f1 = new Font("Amount   :",Font.BOLD,20);
l1.setFont(f1);
Font f2 = new Font("Customer Name  :",Font.BOLD,20);
l2.setFont(f2);
Font f3 = new Font("Item Name   :",Font.BOLD,20);
l3.setFont(f3);
Font f4 = new Font("Batch   :",Font.BOLD,20);
l4.setFont(f4);
Font f5 = new Font("Company ",Font.BOLD,20);
l5.setFont(f5);
Font f6 = new Font("Bill no. :",Font.BOLD,20);
l6.setFont(f6);
Font f7 = new Font("Delivery Add. :",Font.BOLD,20);
l7.setFont(f7);
Font f8 = new Font("Contact no.   :",Font.BOLD,20);
l8.setFont(f8);
Font f9 = new Font("Date  :",Font.BOLD,20);
l9.setFont(f9);
Font f10 = new Font("Item Code :",Font.BOLD,20);
l10.setFont(f10);
Font f11 = new Font("Exp. Date  :",Font.BOLD,20);
l11.setFont(f11);
Font f12 = new Font("Payment Method :",Font.BOLD,20);
l12.setFont(f12);
Font f13 = new Font("BILL",Font.BOLD,120);
l13.setFont(f13);


Font f14 = new Font("Save",Font.BOLD,25);
b3.setFont(f14);
Font f15 = new Font("Cancel",Font.BOLD,25);
b2.setFont(f15);



Font f16 = new Font("cash :",Font.BOLD,20);
c1.setFont(f16);
Font f17 = new Font("cheque  :",Font.BOLD,20);
c2.setFont(f17);
Font f18 = new Font("credit :",Font.BOLD,20);
c3.setFont(f18);
Font f19 = new Font("other",Font.BOLD,20);
c4.setFont(f19);
add(bp);

addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
try
{
Class.forName("com.mysql.jdbc.Driver");    
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/inv","root","root");
st=con.createStatement();//3
rs=st.executeQuery("select * from newbill");
}catch(Exception e)
{
System.out.println("EXC  "+e);
}
}

public void actionPerformed(ActionEvent a)
{

String s1=t1.getText();
String s2=t2.getText();
String s3=t3.getText();
String s4=t4.getText();
String s5=t5.getText();
String s6=t6.getText();
String s7=t7.getText();
String s8=t8.getText();
String s9=t9.getText();
String s11=t11.getText();
String s12=t12.getText();
String s13=null;
if(c1.getState())
{
s13=c1.getLabel();
}
if(c2.getState())
{
s13=c2.getLabel();
}
if(c3.getState())
{
s13=c3.getLabel();
}
if(c4.getState())
{
s13=c4.getLabel();
}


try
{
if(a.getSource()==b3)
{
t1.setText(" "); 
t2.setText(" "); 
t3.setText(" "); 
t4.setText(" "); 
t5.setText(" "); 
t6.setText(" "); 
t7.setText(" "); 
t8.setText(" "); 
t9.setText(" "); 
t10.setText(" "); 
t11.setText(" "); 
t12.setText(" "); 
st.executeUpdate("Insert into newbill values('"+s12+"'"+",'"+s11+"'"+",'"+s1+"'"+",'"+s2+"'"+",'"+s3+"'"+",'"+s4+"'"+",'"+s5+"'"+",'"+s6+"'"+",'"+s7+"'"+",'"+s8+"'"+",'"+s9+"'"+",'"+s13+"'"+")");
JOptionPane.showMessageDialog(null,"Saved Successfully");
}
if(a.getSource()==b2)
{
dispose();
}
rs.close();
st.close();
con.close();

}catch(Exception e){System.out.println("Exc "+e);}
}
}


class BackgroundPanel89 extends Panel
{
Image img;
 BackgroundPanel89()
{
try
{
img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("add1.jpg"), "add1.jpg"));
}
catch(Exception e){/*handled in paint()*/}
}
public void paint(Graphics g)
{
super.paint(g);
if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
else g.drawString("No Image",100,100);
}
}
