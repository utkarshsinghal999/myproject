import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

class vedit extends Frame implements ActionListener
{
Label  l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16;
TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14;
Button b1,b2,b3;
Checkbox c1,c2,c3,c4;
CheckboxGroup cbg=null;
Connection con;Statement st;ResultSet rs;
Font f1,f2;
public void paint(Graphics g)
{
g.drawRect(700,160,600,500);
}
vedit()
{
//setLayout(null);
setSize(1400,730);
setLocation(0,0);
BackgroundPanel96 bp = new BackgroundPanel96();
 
 
l1=new Label("Date         :");
l2=new Label("Vendor Name :");
l3=new Label("Contact no.      :");
l4=new Label("Email            :");
l5=new Label("Fax             :");
l6=new Label("Address            :");

l8=new Label("Item Code        :");
l9=new Label("Item Rate         :");
l10=new Label("Company Name :");
l11=new Label("Amount Due      :");
l12=new Label("Payment Mode  :");
l14=new Label("Bill No.                   :");
l15=new Label("Acc No.(Vender)     :");




l13=new Label("NEW VENDOR");

l16=new Label("ITEMS PURCHASED");

CheckboxGroup cbg=new CheckboxGroup();
c1=new Checkbox("cash",cbg,true);
c2=new Checkbox("cheque",cbg,false);
c3=new Checkbox("credit",cbg,false);
c4=new Checkbox("other",cbg,false);




t1=new TextField(10);
t2=new TextField(20);
t3=new TextField(30);
t4=new TextField(40);
t5=new TextField(50);
t6=new TextField(60);
t7=new TextField(70);
t8=new TextField(80);
t9=new TextField(90);
 
t11=new TextField(110);

t13=new TextField(110);
t14=new TextField(120);

 
b3=new Button("Edit");
b3.setBounds(200,650,100,70);
b3.addActionListener(this);
add(b3);
b2=new Button("Cancel");
b2.setBounds(320,650,100,70);
b2.addActionListener(this);
add(b2);

b1=new Button("Search");
b1.setBounds(440,650,100,70);
b1.addActionListener(this);
add(b1);


l1.setBounds(110,510,180,25);  
l1.setForeground(Color.pink);
l1.setBackground(Color.black);       
add(l1);
l2.setBounds(110,160,170,25);  
l2.setForeground(Color.pink);
l2.setBackground(Color.black);      
add(l2);
l3.setBounds(110,230,170,25); 
l3.setForeground(Color.pink);
l3.setBackground(Color.black);       
add(l3);
l4.setBounds(110,300,170,25); 
l4.setForeground(Color.pink);
l4.setBackground(Color.black);       
add(l4);
l5.setBounds(110,370,170,25);
l5.setForeground(Color.pink);
l5.setBackground(Color.black);        
add(l5);
l6.setBounds(110,440,170,25); 
l6.setForeground(Color.pink);
l6.setBackground(Color.black);     
add(l6);

l8.setBounds(750,350,170,25);  
l8.setForeground(Color.pink);
l8.setBackground(Color.black);    
add(l8);
l9.setBounds(750,400,170,25); 
l9.setForeground(Color.pink);
l9.setBackground(Color.black);    
add(l9);
l10.setBounds(750,450,170,25); 
l10.setForeground(Color.pink);
l10.setBackground(Color.black);   
add(l10);
l11.setBounds(750,500,170,25); 
l11.setForeground(Color.pink);
l11.setBackground(Color.black);    
add(l11);
l12.setBounds(750,600,190,25); 
l12.setForeground(Color.pink);
l12.setBackground(Color.black);   
add(l12);
l13.setBounds(400,50,700,60); 
l13.setForeground(Color.pink);
l13.setBackground(Color.black);   
add(l13);
l14.setBounds(750,550,190,25);  
l14.setForeground(Color.pink);
l14.setBackground(Color.black);  
add(l14);
l15.setBounds(110,580,190,25);  
l15.setForeground(Color.pink);
l15.setBackground(Color.black);  
add(l15);
l16.setBounds(750,175,500,100); 
l16.setForeground(Color.pink);
l16.setBackground(Color.black);   
add(l16);




c1.setBounds(1000,600,90,30);
c1.setForeground(Color.pink);
c1.setBackground(Color.black); 
add(c1);
c2.setBounds(1000,630,90,30);
c2.setForeground(Color.pink);
c2.setBackground(Color.black); 
add(c2);
c3.setBounds(1100,600,90,30);
c3.setForeground(Color.pink);
c3.setBackground(Color.black); 
add(c3);
c4.setBounds(1100,630,90,30);
c4.setForeground(Color.pink);
c4.setBackground(Color.black); 
add(c4);
 



t1.setBounds(400,230,220,35); 
add(t1);
t2.setBounds(400,300,220,35); 
add(t2);
t3.setBounds(400,370,220,35); 
add(t3);
t4.setBounds(400,440,220,35); 
add(t4);
t5.setBounds(1000,350,220,35); 
add(t5);
t6.setBounds(400,510,220,35); 
add(t6);
t7.setBounds(1000,400,220,35); 
add(t7);
t8.setBounds(1000,450,220,35); 
add(t8);
t9.setBounds(1000,500,220,35); 
add(t9);
 
t11.setBounds(400,160,220,35); 
add(t11);

t13.setBounds(1000,550,220,35); 
add(t13);
t14.setBounds(400,580,220,35); 
add(t14);



Font f1 = new Font("Date  :",Font.BOLD,20);
l1.setFont(f1);
Font f2 = new Font("Vendor Name  :",Font.BOLD,20);
l2.setFont(f2);
Font f3 = new Font("Contact No.  :",Font.BOLD,20);
l3.setFont(f3);
Font f4 = new Font("EMail   :",Font.BOLD,20);
l4.setFont(f4);
Font f5 = new Font("Fax ",Font.BOLD,20);
l5.setFont(f5);
Font f6 = new Font("Address :",Font.BOLD,20);
l6.setFont(f6);

Font f8 = new Font("Item Code   :",Font.BOLD,20);
l8.setFont(f8);
Font f9 = new Font("Item Rate  :",Font.BOLD,20);
l9.setFont(f9);
Font f10 = new Font("Company Name :",Font.BOLD,20);
l10.setFont(f10);
Font f11 = new Font("Amount Due  :",Font.BOLD,20);
l11.setFont(f11);
Font f12 = new Font("Payment Mode  :",Font.BOLD,20);
l12.setFont(f12);
Font f13 = new Font("NEW VENDOR",Font.BOLD,80);
l13.setFont(f13);
Font f20 = new Font("Bill No. :",Font.BOLD,20);
l14.setFont(f20);
Font f21 = new Font("Acc No. :",Font.BOLD,20);
l15.setFont(f21);
Font f22 = new Font("ITEMS PURCHASED",Font.BOLD,50);
l16.setFont(f22);


Font f14 = new Font("Edit",Font.BOLD,25);
b3.setFont(f14);
Font f15 = new Font("Cancel",Font.BOLD,25);
b2.setFont(f15);

Font f25 = new Font("Search",Font.BOLD,25);
b1.setFont(f25);



Font f16 = new Font("cash :",Font.BOLD,20);
c1.setFont(f16);
Font f17 = new Font("cheque  :",Font.BOLD,20);
c2.setFont(f17);
Font f18 = new Font("credit :",Font.BOLD,20);
c3.setFont(f18);
Font f19 = new Font("other",Font.BOLD,20);
c4.setFont(f19);

add(bp);
addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});


}

public void actionPerformed(ActionEvent a)
{
try
{
Class.forName("com.mysql.jdbc.Driver");    
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/inv","root","root");
st=con.createStatement();//3

if(a.getSource()== b1)
{

String s1=t1.getText();
String s2=t2.getText();
String s3=t3.getText();
String s4=t4.getText();
String s5=t5.getText();
String s6=t6.getText();
String s7=t7.getText();
String s8=t8.getText();
String s9=t9.getText();
String s11=t11.getText();

String s13=t13.getText();
String s14=t14.getText();
String s15=null;
if(c1.getState())
{
s15=c1.getLabel();
}
if(c2.getState())
{
s15=c2.getLabel();
}
if(c3.getState())
{
s15=c3.getLabel();
}
if(c4.getState())
{
s15=c4.getLabel();
}

rs=st.executeQuery("select * from vendnew where Vendor_name='"+s11+"'");

while(rs.next())
{
s6 = rs.getString("Date");
s11 = rs.getString("Vendor_name");
s1 = rs.getString("Contact_no");
s2 = rs.getString("Email");
s3 = rs.getString("Fax");
s4 = rs.getString("Address");
s5 = rs.getString("Item_code");
s7 = rs.getString("Item_rate");
s8 = rs.getString("Company_name");
s9 = rs.getString("Amount_due");
s15 = rs.getString("Pay_mode");
s13 = rs.getString("Bill_no");
s14 = rs.getString("Acc_no");

t6.setText(s6);
t11.setText(s11);
t1.setText(s1);
t2.setText(s2);
t3.setText(s3);
t4.setText(s4);
t5.setText(s5);
t7.setText(s7);
t8.setText(s8);
t9.setText(s9);
t13.setText(s13);
t14.setText(s14);

if(s15.equals("cash"))
{
cbg.setSelectedCheckbox(c1);
}

if(s15.equals("cheque"))
{
cbg.setSelectedCheckbox(c2);
}

if(s15.equals("credit"))
{
cbg.setSelectedCheckbox(c3);
}

if(s15.equals("other"))
{
cbg.setSelectedCheckbox(c4);
}

}
}
rs.close();
}catch(Exception e){System.out.println("Exc "+e);}

try
{
Class.forName("com.mysql.jdbc.Driver");    
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/inv","root","root");
st=con.createStatement();//3


if(a.getSource()==b3)
{
String s1=t1.getText();
String s2=t2.getText();
String s3=t3.getText();
String s4=t4.getText();
String s5=t5.getText();
String s6=t6.getText();
String s7=t7.getText();
String s8=t8.getText();
String s9=t9.getText();
String s11=t11.getText();
String s13=t13.getText();
String s14=t14.getText();
String s15=null;
if(c1.getState())
{
s15=c1.getLabel();
}
if(c2.getState())
{
s15=c2.getLabel();
}
if(c3.getState())
{
s15=c3.getLabel();
}
if(c4.getState())
{
s15=c4.getLabel();
}
t1.setText(" "); 
t2.setText(" "); 
t3.setText(" "); 
t4.setText(" "); 
t5.setText(" "); 
t6.setText(" "); 
t7.setText(" "); 
t8.setText(" "); 
t9.setText(" "); 
t11.setText(" "); 
t12.setText(" "); 
t13.setText(" "); 
t14.setText(" "); 
st.executeUpdate("UPDATE vendnew SET Date ='"+s6+"',Vendor_name ='"+s11+"',Contact_no ='"+s1+"',Email ='"+s2+"',Fax ='"+s3+"',Address ='"+s4+"',Item_code ='"+s5+"',Item_rate ='"+s7+"',Company_name ='"+s8+"',Amount_due ='"+s9+"',Pay_mode ='"+s15+"',Bill_no ='"+s13+"',Acc_no ='"+s14+"'");
JOptionPane.showMessageDialog(null,"Updated Successfully");
}
if(a.getSource()==b2)
{
dispose();
}
st.close();
con.close();

}catch(Exception e){System.out.println("Exc "+e);}
}
}

class BackgroundPanel96 extends Panel
{
Image img;
 BackgroundPanel96()
{
try
{
img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("add1.jpg"), "add1.jpg"));
}
catch(Exception e){/*handled in paint()*/}
}
public void paint(Graphics g)
{
super.paint(g);
if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
else g.drawString("No Image",100,100);
}
}