import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
class iedit extends Frame implements ActionListener
{
Label  l2,l3,l4,l5,l6,l8,l9,l10,l11,l12,l13;
TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
Connection con;Statement st;ResultSet rs;
Button b1,b2,b3,b4;
Font f1,f2;
public void paint(Graphics g)
{
g.drawRect(30,200,1270,400);
}
iedit()
{
//setLayout(null);
setSize(1400,730);
setLocation(0,0);
BackgroundPanel92 bp = new BackgroundPanel92();
l2=new Label("Item Name - 1    :");
l3=new Label("Item Code          :");
l4=new Label("Date of mag.      :");
l5=new Label("Date of exp.       :");
l6=new Label("Company           :");
l8=new Label("Location             :");
l9=new Label("Batch                 :");
l10=new Label("Purchase Price  :");
l11=new Label("Closing Stock    :");
l12=new Label("Re-order Value  :");
l13=new Label("NEW ITEM");
 






t1=new TextField(10);
t2=new TextField(20);
t3=new TextField(30);
t4=new TextField(40);
t5=new TextField(50);
t6=new TextField(60);
t7=new TextField(70);
t8=new TextField(80);
t9=new TextField(90);
t10=new TextField(100);

 
b3=new Button("Edit");
b3.setBounds(500,630,100,70);
b3.addActionListener(this);
add(b3);
b4=new Button("CANCEL");
b4.setBounds(650,630,120,70);
b4.addActionListener(this);
add(b4);

b1=new Button("Search");
b1.setBounds(350,630,100,70);
b1.addActionListener(this);
add(b1);

l8.setBounds(700,230,180,25);  
l8.setForeground(Color.pink);
l8.setBackground(Color.black);       
add(l8);
l2.setBounds(110,230,170,25); 
l2.setForeground(Color.pink);
l2.setBackground(Color.black);       
add(l2);
l3.setBounds(110,300,170,25); 
l3.setForeground(Color.pink);
l3.setBackground(Color.black);       
add(l3);
l4.setBounds(110,370,170,25); 
l4.setForeground(Color.pink);
l4.setBackground(Color.black);       
add(l4);
l5.setBounds(110,440,170,25);  
l5.setForeground(Color.pink);
l5.setBackground(Color.black);      
add(l5);
l6.setBounds(110,510,170,25); 
l6.setForeground(Color.pink);
l6.setBackground(Color.black);     
add(l6);
l9.setBounds(700,300,170,25); 
l9.setForeground(Color.pink);
l9.setBackground(Color.black);     
add(l9);
l10.setBounds(700,370,170,25);
l10.setForeground(Color.pink);
l10.setBackground(Color.black);     
add(l10);
l11.setBounds(700,440,170,25);
l11.setForeground(Color.pink);
l11.setBackground(Color.black);    
add(l11);
l12.setBounds(700,510,170,25);
l12.setForeground(Color.pink);
l12.setBackground(Color.black);     
add(l12);
l13.setBounds(400,70,700,100);
l13.setForeground(Color.pink);
l13.setBackground(Color.black);    
add(l13);
 



t1.setBounds(400,300,220,35); 
add(t1);
t2.setBounds(400,370,220,35); 
add(t2);
t3.setBounds(400,440,220,35); 
add(t3);
t4.setBounds(400,510,220,35); 
add(t4);
t5.setBounds(400,230,220,35); 
add(t5);
t6.setBounds(1000,300,220,35); 
add(t6);
t7.setBounds(1000,370,220,35); 
add(t7);
t8.setBounds(1000,440,220,35); 
add(t8);
t9.setBounds(1000,510,220,35); 
add(t9);
t10.setBounds(1000,230,220,35); 
add(t10);


Font f2 = new Font("Item Name - 1  :",Font.BOLD,20);
l2.setFont(f2);
Font f3 = new Font("Item Code  :",Font.BOLD,20);
l3.setFont(f3);
Font f4 = new Font("Date of mag.  :",Font.BOLD,20);
l4.setFont(f4);
Font f5 = new Font("Date of exp.",Font.BOLD,20);
l5.setFont(f5);
Font f6 = new Font("Company  :",Font.BOLD,20);
l6.setFont(f6);

Font f8 = new Font("Location  :",Font.BOLD,20);
l8.setFont(f8);
Font f9 = new Font("Batch  :",Font.BOLD,20);
l9.setFont(f9);
Font f10 = new Font("Purchase Price  :",Font.BOLD,20);
l10.setFont(f10);
Font f11 = new Font("Closing Stock  :",Font.BOLD,20);
l11.setFont(f11);
Font f12 = new Font("Re-order Value  :",Font.BOLD,20);
l12.setFont(f12);
Font f13 = new Font("ADD ITEM",Font.BOLD,100);
l13.setFont(f13);
Font f14 = new Font("Save",Font.BOLD,25);
b3.setFont(f14);
Font f15 = new Font("Cancel",Font.BOLD,25);
b4.setFont(f15);

Font f16 = new Font("Search",Font.BOLD,25);
b1.setFont(f16);
add(bp);
addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});

}

public void actionPerformed(ActionEvent a)
{
try
{
Class.forName("com.mysql.jdbc.Driver");    
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/inv","root","root");
Statement st=con.createStatement();//3
if(a.getSource()==b1)
{

String s1=t1.getText();
String s2=t2.getText();
String s3=t3.getText();
String s4=t4.getText();
String s5=t5.getText();
String s6=t6.getText();
String s7=t7.getText();
String s8=t8.getText();
String s9=t9.getText();
String s10=t10.getText();
ResultSet rs=st.executeQuery("select * from aditem where Item_code='"+s1+"'");

while(rs.next())
{
s5 = rs.getString("Item_name");
s1 = rs.getString("Item_code");
s2 = rs.getString("mfg_date");
s3 = rs.getString("exp_date");
s4 = rs.getString("company");
s10 = rs.getString("location");
s6 = rs.getString("batch");
s7 = rs.getString("purchase_price");
s8 = rs.getString("closing_stock");
s9 = rs.getString("Reorder_value");

t5.setText(s5);
t1.setText(s1);
t2.setText(s2);
t3.setText(s3);
t4.setText(s4);
t10.setText(s10);
t6.setText(s6);
t7.setText(s7);
t8.setText(s8);
t9.setText(s9);
}
}
rs.close();
}catch(Exception e){System.out.println("EXC" +e);}

try
{
Class.forName("com.mysql.jdbc.Driver");    
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/inv","root","root");
st=con.createStatement();

if(a.getSource()==b3)
{
String s1=t1.getText();
String s2=t2.getText();
String s3=t3.getText();
String s4=t4.getText();
String s5=t5.getText();
String s6=t6.getText();
String s7=t7.getText();
String s8=t8.getText();
String s9=t9.getText();
String s10=t10.getText();

t1.setText(" "); 
t2.setText(" "); 
t3.setText(" "); 
t4.setText(" "); 
t5.setText(" "); 
t6.setText(" "); 
t7.setText(" "); 
t8.setText(" "); 
t9.setText(" "); 
t10.setText(" "); 
st.executeUpdate("UPDATE aditem SET Item_name ='"+s5+"',Item_code ='"+s1+"',mfg_date ='"+s2+"',exp_date ='"+s3+"',company ='"+s4+"',location ='"+s10+"',batch ='"+s6+"',purchase_price ='"+s7+"',closing_stock ='"+s8+"',Reorder_value ='"+s9+"'");
JOptionPane.showMessageDialog(null,"Updated Successfully");
}
if(a.getSource()==b4)
{
dispose();
}
st.close();
con.close();
}catch(Exception e){System.out.println("Exp" +e);}
}
}

class BackgroundPanel92 extends Panel
{
Image img;
 BackgroundPanel92()
{
try
{
img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("add1.jpg"), "add1.jpg"));
}
catch(Exception e){/*handled in paint()*/}
}
public void paint(Graphics g)
{
super.paint(g);
if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
else g.drawString("No Image",100,100);
}
}