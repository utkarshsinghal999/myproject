import java.awt.*;
import java.awt.event.*;

class newgui3 extends Frame implements ActionListener
{
Label l1,l2;Button b1; Font f1,f2,f3,f4;
newgui3()
{
//setLayout(null);
setSize(1400,730);
setLocation(0,0);
BackgroundPanel31 bp = new BackgroundPanel31();



l2=new Label("INVENTORY  SYSTEM");
Font f3 = new Font("INVENTORY  SYSTEM",Font.BOLD,90);
l2.setFont(f3);
l2.setBounds(260,80,950,100);
add(l2);






b1=new Button("START");
Font f2 = new Font("START",Font.BOLD,50);
b1.setForeground(Color.black);
b1.setBackground(Color.cyan);
b1.setFont(f2);
b1.setBounds(600,550,200,50);
b1.addActionListener(this);
add(b1); 
add(bp);


addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
 
}



public void actionPerformed(ActionEvent ae)
{
my2 m1=new my2();
m1.setSize(1500,1500);
m1.setBackground(Color.black);
m1.setTitle("Login Page");
m1.setVisible(true);
}
}
class gui3
{
public static void main(String args[])
{
my m1=new my();
m1.setSize(1410,730);
m1.setBackground(Color.cyan);
m1.setTitle("Welcome Frame");
m1.setVisible(true);
}
}

class BackgroundPanel31 extends Panel
{
Image img;
 BackgroundPanel31()
{
try
{
img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("welcome.jpg"), "welcome.jpg"));
}
catch(Exception e){/*handled in paint()*/}
}
public void paint(Graphics g)
{
super.paint(g);
if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
else g.drawString("No Image",100,100);
}
}