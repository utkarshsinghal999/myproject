/*
SQLyog - Free MySQL GUI v5.17
Host - 5.0.24-community-nt : Database - inv
*********************************************************************
Server version : 5.0.24-community-nt
*/

SET NAMES utf8;

SET SQL_MODE='';

create database if not exists `inv`;

USE `inv`;

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

/*Table structure for table `customer` */

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `Customer Name` char(30) default NULL,
  `Phone` int(11) default NULL,
  `Mobile` int(14) default NULL,
  `Email` varchar(20) default NULL,
  `Fax` varchar(20) default NULL,
  `Delivery Address` varchar(30) default NULL,
  `Bank Account No.` varchar(15) default NULL,
  `IFSC Code` varchar(10) default NULL,
  `Reference` varchar(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `customer` */

insert into `customer` (`Customer Name`,`Phone`,`Mobile`,`Email`,`Fax`,`Delivery Address`,`Bank Account No.`,`IFSC Code`,`Reference`) values ('Dawaghar',744,2147483647,'Dawaghar@gmail.com','23456789101','Sudha hospital, kota','61240381521','SBI0339363','-');

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
