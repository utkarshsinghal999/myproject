import java.awt.*; 
import java.awt.event.*;
import java.sql.*;
class mg1 extends Frame 
{
Button b1,b2,b3;
TextField t1,t2,t3,t4;
Label l1,l2,l3,l4,l5;
MenuBar mb;
Menu menu,menu1;
MenuItem i1,i2,i3,i4,i5,i6;
Connection con;Statement st;ResultSet rs;
mg1(String ss)
{

//FlowLayout f1=new FlowLayout();
setLayout(null);
mb=new MenuBar();
menu=new Menu("Item");
i1=new MenuItem("New");
i2=new MenuItem("edit");
i3=new MenuItem("Delete");
i4=new MenuItem("view");
menu.add(i1);
menu.add(i2);
menu.add(i3);
menu.add(i4);
}
}
