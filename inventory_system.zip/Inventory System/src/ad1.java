import java.awt.*; 
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
class ad1 extends Frame implements ActionListener 
{
Button b1,b2,b3;
TextField t1,t2,t3,t4;
Label l1,l2,l3,l4,l5;
MenuBar mb;
Menu menu,menu1,menu2,menu3;
MenuItem i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16;
Connection con;Statement st;ResultSet rs;
ad1()
{

//FlowLayout f1=new FlowLayout();
//setLayout(null);
setSize(1400,730);
setLocation(0,0);
BackgroundPanel44 bp = new BackgroundPanel44();

mb=new MenuBar();
menu=new Menu("Item");
i1=new MenuItem("New");
i2=new MenuItem("edit");
i3=new MenuItem("Delete");
i4=new MenuItem("view");
menu.add(i1);
menu.add(i2);
menu.add(i3);
menu.add(i4);

i1.addActionListener(this);
i3.addActionListener(this);
i2.addActionListener(this);
i4.addActionListener(this);
menu1=new Menu("Billing");
i5=new MenuItem("New");
i6=new MenuItem("edit");
i7=new MenuItem("Delete");
i8=new MenuItem("view");
menu1.add(i5);
menu1.add(i6);
menu1.add(i7);
menu1.add(i8);

i5.addActionListener(this);
i7.addActionListener(this);
i6.addActionListener(this);
i8.addActionListener(this);
menu2=new Menu("Customer");
i9=new MenuItem("New");
i10=new MenuItem("edit");
i11=new MenuItem("Delete");
i12=new MenuItem("view");
menu2.add(i9);
menu2.add(i10);
menu2.add(i11);
menu2.add(i12);

i9.addActionListener(this);
i11.addActionListener(this);
i12.addActionListener(this);
i10.addActionListener(this);
menu3=new Menu("Vendor");
i13=new MenuItem("New");
i14=new MenuItem("edit");
i15=new MenuItem("Delete");
i16=new MenuItem("view");
menu3.add(i13);
menu3.add(i14);
menu3.add(i15);
menu3.add(i16);



i13.addActionListener(this);
i15.addActionListener(this);
i16.addActionListener(this);
i14.addActionListener(this);
mb.add(menu);
mb.add(menu1);
mb.add(menu2);
mb.add(menu3);
setMenuBar(mb);


add(bp);
addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
}
public void actionPerformed(ActionEvent a)
{
if(a.getSource()== i1)
{
my3 m3=new my3();
m3.setSize(1400,730);
m3.setBackground(Color.pink);
m3.setTitle("Add Item");
m3.setVisible(true);
}
if(a.getSource()== i5)
{
my4 m4=new my4();
m4.setSize(1400,730);
m4.setBackground(Color.PINK);
m4.setTitle("BILL");
m4.setVisible(true);
}
if(a.getSource()== i9)
{
my5 m5=new my5();
m5.setSize(1400,730);
m5.setBackground(Color.pink);
m5.setTitle("Add New Customer");
m5.setVisible(true);
}
if(a.getSource()== i13)
{
my6 m6=new my6();
m6.setSize(1400,730);
m6.setBackground(Color.pink);
m6.setTitle("NEW VENDOR");
m6.setVisible(true);
}
if(a.getSource()== i3)
{
my7 m7=new my7();
m7.setSize(500,500);
m7.setBackground(Color.pink);
m7.setTitle("Delete Item");
m7.setVisible(true);
}
if(a.getSource()== i7)
{
my8 m8=new my8();
m8.setSize(500,500);
m8.setBackground(Color.green);
m8.setTitle("Delete bill");
m8.setVisible(true);
}
if(a.getSource()== i11)
{
my9 m9=new my9();
m9.setSize(500,500);
m9.setBackground(Color.pink);
m9.setTitle("Delete Customer");
m9.setVisible(true);
}
if(a.getSource()== i15)
{
my11 m11=new my11();
m11.setSize(500,500);
m11.setBackground(Color.pink);
m11.setTitle("Delete vend");
m11.setVisible(true);
}
if(a.getSource()== i2)
{
iedit m15=new iedit();
m15.setSize(1400,730);
m15.setBackground(Color.pink);
m15.setTitle("Edit item");
m15.setVisible(true);
}
if(a.getSource()== i10)
{
cedit m13=new cedit();
m13.setSize(1400,730);
m13.setBackground(Color.pink);
m13.setTitle("Edit Cust");
m13.setVisible(true);
}
if(a.getSource()== i6)
{
bedit m16=new bedit();
m16.setSize(1400,730);
m16.setBackground(Color.pink);
m16.setTitle("Edit bill");
m16.setVisible(true);
}
if(a.getSource()== i14)
{
vedit m30=new vedit();
m30.setSize(1400,730);
m30.setBackground(Color.pink);
m30.setTitle("Edit vend");
m30.setVisible(true);
}
if(a.getSource()== i4)
{
JFrame frame = new userlist();
        frame.setTitle("Item View");
        frame.setSize(1500, 1300);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
if(a.getSource()== i8)
{
JFrame frame = new userlist1();
        frame.setTitle("bill View");
        frame.setSize(1500, 1300);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
if(a.getSource()== i12)
{
JFrame frame = new userlist2();
        frame.setTitle("Customer View");
        frame.setSize(1400, 730);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
}
if(a.getSource()== i16)
{
 JFrame frame = new userlist3();
        frame.setTitle("Vender View");
       
        frame.setSize(1400,730);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}

}
}

class BackgroundPanel44 extends Panel
{
Image img;
 BackgroundPanel44()
{
try
{
img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("add1.jpg"), "add1.jpg"));
}
catch(Exception e){/*handled in paint()*/}
}
public void paint(Graphics g)
{
super.paint(g);
if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
else g.drawString("No Image",100,100);
}
}