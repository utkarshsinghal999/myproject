
import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
class userlist3 extends JFrame {
    DefaultTableModel model = new DefaultTableModel();
    Container cnt = this.getContentPane();
    JTable jtbl = new JTable(model);
    public userlist3() {
        
        model.addColumn("Date");
        model.addColumn("Vendor Name");
        model.addColumn("Contact No.");
        model.addColumn("E-mail");
        model.addColumn("Fax");
        model.addColumn("Address");
        model.addColumn("Item Code");
        model.addColumn("Item Rate");
        model.addColumn("Company");
        model.addColumn("Amount Due");
        model.addColumn("Payment Mode");
        model.addColumn("Bill No.");
        model.addColumn("Account No.");
        
       
    jtbl.setBounds(1400,730,1400,730);
    jtbl.getTableHeader().setBackground(Color.PINK);
    jtbl.getTableHeader().setFont(new Font("Arial",Font.BOLD,20));
    jtbl.getTableHeader().setPreferredSize(new Dimension(20,50));
    jtbl.setFont(new Font("Arial",Font.PLAIN,15));
    
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/inv", "root", "root");
            PreparedStatement pstm = con.prepareStatement("SELECT * FROM vendnew");
            ResultSet Rs = pstm.executeQuery();
            while(Rs.next()){
                model.addRow(new Object[]{Rs.getDate(1), Rs.getString(2),Rs.getInt(3),Rs.getString(4),Rs.getInt(5),Rs.getString(6),Rs.getInt(7),Rs.getInt(8),Rs.getString(9),Rs.getInt(10),Rs.getString(11),Rs.getInt(12),Rs.getInt(13)});
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        JScrollPane pg = new JScrollPane(jtbl);
        cnt.add(pg);
        this.pack();
         pg.getViewport().setBackground(Color.GRAY);
    }
}