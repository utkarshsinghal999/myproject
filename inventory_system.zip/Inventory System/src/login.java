import java.awt.*;
import java.sql.*;
class my2 extends Frame
{
Label l1,l2,l3; Button b1,b2; TextField t1,t2; Font f1,f2,f3;
my2()
{
setLayout(null);
l1=new Label("LOGIN PAGE");
f1=new Font("LOGIN PAGE",Font.BOLD,75);
l1.setFont(f1);
l2=new Label("username");
f2=new Font("USERNAME",Font.BOLD,30);
l2.setFont(f2);
l3=new Label("password");
f3=new Font("PASSWORD",Font.BOLD,30);
l3.setFont(f3);
b1=new Button("LOGIN");
b2=new Button("CANCEL");
t1=new TextField(20);
t2=new TextField(20);
l1.setBounds(390,100,800,90);
add(l1);
l2.setBounds(400,300,170,40);
add(l2);
l3.setBounds(400,350,170,40);
add(l3);
t1.setBounds(600,300,200,40);
add(t1);
t2.setBounds(600,350,200,40);
add(t2);
b1.setBounds(650,420,60,40);
add(b1);
b2.setBounds(720,420,60,40);
add(b2);

}

}
