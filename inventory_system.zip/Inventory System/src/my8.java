import java.awt.*;
import java.awt.event.*;
import java.sql.*;
class my8 extends Frame implements ActionListener
{
Label  l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13;
TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12;
Button b1,b2,b3;
Checkbox c1,c2,c3,c4;
Font f1,f2;
Connection con;Statement st;ResultSet rs;

my8()
{
setLayout(null);

l1=new Label("Bill no.:");




t1=new TextField(10);


b3=new Button("Delete");
b3.setBounds(150,210,70,50);
b3.addActionListener(this);
add(b3);
b2=new Button("Cancel");
b2.setBounds(250,210,70,50);
b2.addActionListener(this);
add(b2);


l1.setBounds(100,150,110,25);        
add(l1);

t1.setBounds(250,150,100,35); 
add(t1);


Font f6 = new Font("Bill no. :",Font.BOLD,20);
l1.setFont(f6);

addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
try
{
Class.forName("com.mysql.jdbc.Driver");    
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/inv","root","root");
st=con.createStatement();

rs=st.executeQuery("select * from newbill");
}catch(Exception e)
{
System.out.println("EXC  "+e);
}
}

public void actionPerformed(ActionEvent a)
{

String s1=t1.getText();
try
{


st.executeUpdate("DELETE FROM newbill WHERE Bill_no='"+s1+"'  ");
if(a.getSource()==b2)
{
dispose();
}
rs.close();
st.close();
con.close();

}catch(Exception e){System.out.println("Exc "+e);}



}


}




