import javax.swing.table.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
class userlist2 extends JFrame {
    DefaultTableModel model = new DefaultTableModel();
    Container cnt = this.getContentPane();
    JTable jtbl = new JTable(model);
    
        
      
    
    public userlist2() {
       
        model.addColumn("Customer Name");
        model.addColumn("Mobile_no.");
        model.addColumn("Phone_no.");
        model.addColumn("Email_id");
        model.addColumn("Fax");
        model.addColumn("Delivery_Add");
        model.addColumn("Transporter");
        model.addColumn("Bank_acc");
        model.addColumn("IFSC");
        model.addColumn("Reference");
   
    jtbl.setBounds(1400,730,1400,730);
    jtbl.getTableHeader().setBackground(Color.PINK);
    jtbl.getTableHeader().setFont(new Font("Arial",Font.BOLD,20));
    jtbl.getTableHeader().setPreferredSize(new Dimension(20,50));
    jtbl.setFont(new Font("Arial",Font.PLAIN,15));
    
   try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/inv", "root", "root");
            PreparedStatement pstm = con.prepareStatement("SELECT * FROM newcust");
            ResultSet Rs = pstm.executeQuery();
            
            while(Rs.next()){
                model.addRow(new Object[]{Rs.getString(1), Rs.getInt(2),Rs.getInt(3),Rs.getString(4),Rs.getString(5),Rs.getString(6),Rs.getString(7),Rs.getInt(8),Rs.getString(9),Rs.getString(10)});
            }
            
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
          
        JScrollPane pg = new JScrollPane(jtbl);
        cnt.add(pg);
        this.pack();
   
        pg.getViewport().setBackground(Color.GRAY);
    }
}