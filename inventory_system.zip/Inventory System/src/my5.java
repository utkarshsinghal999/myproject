import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
class my5 extends Frame implements ActionListener
{
Label  l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10 ;
Connection con;Statement st;ResultSet rs;
Button b1,b2,b3;
Font f1,f2;
public void paint(Graphics g)
{
g.drawRect(30,200,1270,400);
}
my5()
{
//setLayout(null);
setSize(1400,730);
setLocation(0,0);
BackgroundPanel88 bp = new BackgroundPanel88();
l1=new Label(" NEW CUSTOMER");
l2=new Label("Customer Name    :");
l3=new Label("Mobile No          :");
l4=new Label("Phone No.              :");
l5=new Label("Email ID                :");
l6=new Label("Fax                      :");
l7=new Label("Deleivery Address     :");
l8=new Label("Transporter             :");
l9=new Label("Bank ACC.No.          :");
l10=new Label("IFSC Code                :");
l11=new Label("(Office/Residence)"); 
 l12=new Label("Reference                :");






t1=new TextField(10);
t2=new TextField(20);
t3=new TextField(30);
t4=new TextField(40);
t5=new TextField(50);
t6=new TextField(60);
t7=new TextField(70);
t8=new TextField(80);
t9=new TextField(90);
t10=new TextField(90); 

b3=new Button("Save");
b3.setBounds(550,620,100,70);
b3.addActionListener(this);
add(b3);
b1=new Button("Cancel");
b1.setBounds(700,620,100,70);
b1.addActionListener(this);
add(b1);


l1.setBounds(220,80,1000,100); 
l1.setForeground(Color.pink);
l1.setBackground(Color.black);        
add(l1);
l2.setBounds(60,250,200,25);   
l2.setForeground(Color.pink);
l2.setBackground(Color.black);     
add(l2);
l3.setBounds(60,320,200,25); 
l3.setForeground(Color.pink);
l3.setBackground(Color.black);       
add(l3);
l4.setBounds(60,390,200,25); 
l4.setForeground(Color.pink);
l4.setBackground(Color.black);       
add(l4);
l5.setBounds(60,460,200,25); 
l5.setForeground(Color.pink);
l5.setBackground(Color.black);       
add(l5);
l6.setBounds(60,530,200,25); 
l6.setForeground(Color.pink);
l6.setBackground(Color.black);     
add(l6);
l7.setBounds(700,460,220,25); 
l7.setForeground(Color.pink);
l7.setBackground(Color.black);      
add(l7);

l8.setBounds(700,250,200,25); 
l8.setForeground(Color.pink);
l8.setBackground(Color.black);     
add(l8);
l9.setBounds(700,320,200,25); 
l9.setForeground(Color.pink);
l9.setBackground(Color.black);    
add(l9);
l10.setBounds(700,390,210,25); 
l10.setForeground(Color.pink);
l10.setBackground(Color.black);   
add(l10);
l11.setBounds(40,415,270,25);  
l11.setForeground(Color.pink);
l11.setBackground(Color.black);      
add(l11);
l12.setBounds(700,530,210,25); 
l12.setForeground(Color.pink);
l12.setBackground(Color.black);   
add(l12);



t1.setBounds(400,250,220,35); 
add(t1);
t2.setBounds(400,320,220,35); 
add(t2);
t3.setBounds(400,390,220,35); 
add(t3);
t4.setBounds(400,460,220,35); 
add(t4);
t5.setBounds(1050,460,220,35); 
add(t5);
t6.setBounds(1050,250,220,35); 
add(t6);
t7.setBounds(1050,320,220,35); 
add(t7);
t8.setBounds(1050,390,220,35); 
add(t8);
t9.setBounds(400,530,220,35); 
add(t9);
t10.setBounds(1050,530,220,35); 
add(t10);
 

Font f1 = new Font(" NEW CUSTOMER",Font.BOLD,100);
l1.setFont(f1);
Font f2 = new Font("Customer Name      :",Font.BOLD,20);
l2.setFont(f2);
Font f3 = new Font("Mobile No      :",Font.BOLD,20);
l3.setFont(f3);
Font f4 = new Font("Phone No.(office/residence)     :",Font.BOLD,20);
l4.setFont(f4);
Font f5 = new Font("Email ID         :",Font.BOLD,20);
l5.setFont(f5);
Font f6 = new Font("Fax          :",Font.BOLD,20);
l6.setFont(f6);
Font f7 = new Font("Deleivery Address    :",Font.BOLD,20);
l7.setFont(f7);
Font f8 = new Font("Transporter      :",Font.BOLD,20);
l8.setFont(f8);
Font f9 = new Font("Bank ACC.No.     :",Font.BOLD,20);
l9.setFont(f9);
Font f10 = new Font("IFSC Code  :",Font.BOLD,20);
l10.setFont(f10);
Font f11 = new Font("(personal/office/residency)",Font.BOLD,20);
l11.setFont(f11);
Font f16 = new Font("(personal/office/residency)",Font.BOLD,20);
l12.setFont(f16
);



 
Font f14 = new Font("Save",Font.BOLD,25);
b3.setFont(f14);
Font f15 = new Font("Cancel",Font.BOLD,25);
b1.setFont(f15);
add(bp);
addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        System.exit(0);}});
try
{
Class.forName("com.mysql.jdbc.Driver");    
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/inv","root","root");
st=con.createStatement();//3
rs=st.executeQuery("select * from newcust");
}catch(Exception e)
{
System.out.println("EXC  "+e);
}
}
public void actionPerformed(ActionEvent a)
{

String s1=t1.getText();
String s2=t2.getText();
String s3=t3.getText();
String s4=t4.getText();
String s5=t5.getText();
String s6=t6.getText();
String s7=t7.getText();
String s8=t8.getText();
String s9=t9.getText();
String s10=t10.getText();

try
{
if(a.getSource()==b3)
{
t1.setText(" "); 
t2.setText(" "); 
t3.setText(" "); 
t4.setText(" "); 
t5.setText(" "); 
t6.setText(" "); 
t7.setText(" "); 
t8.setText(" "); 
t9.setText(" "); 
t10.setText(" "); 
st.executeUpdate("Insert into newcust values('"+s1+"'"+",'"+s2+"'"+",'"+s3+"'"+",'"+s4+"'"+",'"+s9+"'"+",'"+s5+"'"+",'"+s6+"'"+",'"+s7+"'"+",'"+s8+"'"+",'"+s10+"'"+")");
JOptionPane.showMessageDialog(null,"Saved Successfully");
}
if(a.getSource()==b1)
{
dispose();
}
rs.close();
st.close();
con.close();
}catch(Exception e){System.out.println("EXC" +e);}
}
}
class BackgroundPanel90 extends Panel
{
Image img;
 BackgroundPanel90()
{
try
{
img = Toolkit.getDefaultToolkit().createImage(new java.net.URL(getClass().getResource("add1.jpg"), "add1.jpg"));
}
catch(Exception e){/*handled in paint()*/}
}
public void paint(Graphics g)
{
super.paint(g);
if(img != null) g.drawImage(img, 0,0,this.getWidth(),this.getHeight(),this);
else g.drawString("No Image",100,100);
}
}
