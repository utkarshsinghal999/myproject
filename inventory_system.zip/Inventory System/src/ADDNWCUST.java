import java.awt.*;
class my extends Frame
{
Label  l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12;
TextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10 ;
Button b1,b2,b3;
Font f1,f2;
public void paint(Graphics g)
{
g.drawRect(30,200,1270,400);
}
my()
{
setLayout(null);
 
 
l1=new Label(" NEW CUSTOMER");
l2=new Label("Customer Name    :");
l3=new Label("Mobile No.          :");
l4=new Label("Phone No.              :");
l5=new Label("Email ID                :");
l6=new Label("Fax                      :");
l7=new Label("Deleivery Address     :");
l8=new Label("Transporter             :");
l9=new Label("Bank ACC.No.          :");
l10=new Label("IFSC Code                :");
l11=new Label("(Office/Residence)"); 
 l12=new Label("Reference                :");






t1=new TextField(10);
t2=new TextField(20);
t3=new TextField(30);
t4=new TextField(40);
t5=new TextField(50);
t6=new TextField(60);
t7=new TextField(70);
t8=new TextField(80);
t9=new TextField(90);
t10=new TextField(90); 

b3=new Button("Save");
b3.setBounds(550,620,100,70);
add(b3);
b1=new Button("Cancel");
b1.setBounds(700,620,100,70);
add(b1);


l1.setBounds(220,80,1000,100);        
add(l1);
l2.setBounds(60,250,200,25);       
add(l2);
l3.setBounds(60,320,200,25);       
add(l3);
l4.setBounds(60,390,200,25);       
add(l4);
l5.setBounds(60,460,200,25);       
add(l5);
l6.setBounds(60,530,200,25);     
add(l6);
l7.setBounds(700,460,220,25);      
add(l7);

l8.setBounds(700,250,200,25);     
add(l8);
l9.setBounds(700,320,200,25);    
add(l9);
l10.setBounds(700,390,210,25);   
add(l10);
l11.setBounds(40,415,270,25);       
add(l11);
l12.setBounds(700,530,210,25);   
add(l12);



t1.setBounds(400,250,220,35); 
add(t1);
t2.setBounds(400,320,220,35); 
add(t2);
t3.setBounds(400,390,220,35); 
add(t3);
t4.setBounds(400,460,220,35); 
add(t4);
t5.setBounds(1050,460,220,35); 
add(t5);
t6.setBounds(1050,250,220,35); 
add(t6);
t7.setBounds(1050,320,220,35); 
add(t7);
t8.setBounds(1050,390,220,35); 
add(t8);
t9.setBounds(400,530,220,35); 
add(t9);
t10.setBounds(1050,530,220,35); 
add(t10);
 

Font f1 = new Font(" NEW CUSTOMER",Font.BOLD,100);
l1.setFont(f1);
Font f2 = new Font("Customer Name      :",Font.BOLD,20);
l2.setFont(f2);
Font f3 = new Font("Mobile No.       :",Font.BOLD,20);
l3.setFont(f3);
Font f4 = new Font("Phone No.(office/residence)     :",Font.BOLD,20);
l4.setFont(f4);
Font f5 = new Font("Email ID         :",Font.BOLD,20);
l5.setFont(f5);
Font f6 = new Font("Fax          :",Font.BOLD,20);
l6.setFont(f6);
Font f7 = new Font("Deleivery Address    :",Font.BOLD,20);
l7.setFont(f7);
Font f8 = new Font("Transporter      :",Font.BOLD,20);
l8.setFont(f8);
Font f9 = new Font("Bank ACC.No.     :",Font.BOLD,20);
l9.setFont(f9);
Font f10 = new Font("IFSC Code  :",Font.BOLD,20);
l10.setFont(f10);
Font f11 = new Font("(personal/office/residency)",Font.BOLD,20);
l11.setFont(f11);
Font f16 = new Font("(personal/office/residency)",Font.BOLD,20);
l12.setFont(f16
);



 
Font f14 = new Font("Save",Font.BOLD,25);
b3.setFont(f14);
Font f15 = new Font("Cancel",Font.BOLD,25);
b1.setFont(f15);
}
}
class ADDNWCUST
{
public static void main(String args[])
{
my m1=new my();
m1.setSize(1400,730);
m1.setBackground(Color.pink);
m1.setTitle("Add New Customer");
m1.setVisible(true);
}
}